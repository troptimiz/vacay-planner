var express = require('express');
var ProductController = express();
var Product = require('../models/products.js');
var ClassificationGroup = require('../models/classification.js');
var bodyParser = require('body-parser');

ProductController.use(bodyParser());
var multer = require('multer');
var fs = require('fs');
var imageName ="";
var mongoose = require('mongoose');
var Grid = require('gridfs-stream');
var gfs = Grid(mongoose.connection.db, mongoose.mongo);
var dirname = require('path').dirname(__dirname);

var Passport = require('passport');
var flash = require('connect-flash'); 
var bodyParser = require('body-parser');
var cookieParser = require('cookie-parser'); 
var expressSession = require('express-session');
ProductController.use(bodyParser());
ProductController.use(cookieParser());
ProductController.use(expressSession({ secret: '1234QWERTY'}));
ProductController.use(Passport.initialize());
ProductController.use(Passport.session());
ProductController.use(flash());

/*File uplaod*/
/*CategoryController.use(multer({ dest: './uploads/',
    rename: function (fieldname, filename) {
        return filename+Date.now();
    },
    onFileUploadStart: function (file) {
      console.log(file.originalname + ' is starting ...')
    },
    onFileUploadComplete: function (file) {
      console.log(file.fieldname + ' uploaded to  ' + file.name);
        imageName = file.name;
      done=true;
    },
    onError: function (error, next) {
      console.log(error)
      next(error)
    }
}));*/

// All Active Products
ProductController.get('/',function(req,res){
	Product.find({"is_active":true},function(err,products){
		res.status(200).json({'data':products});
	});
});

// Retrieve Products by category name

ProductController.get('/category/:name',function(req,res){
	var categoryName = req.params.name;

	Product.find({"category":categoryName,"is_active":true},function(err,products){
		res.status(200).json({'data':products});
	}).sort( { _id: -1 } );
});

// Create new Product 

ProductController.put('/product/',function(req,res){
    var classification = req.body.classification;
    var classificationArray = [];
    //var classificationArray = classification.split(",");
    if(typeof(classification) == 'string'){
        classificationArray.push({"name":classification});   
    }
    else{
        classification.forEach(function(item){
            classificationArray.push({"name":item});
        });
    }
    console.log(classificationArray);
	var product = new Product({
		category:req.body.category,
		name:req.body.name,	
		type:req.body.type,
		description:req.body.description,
		emailAddress:req.body.emailAddress,
		is_active:req.body.is_active,
        images:[],
		addresses:[],
		phoneNumbers:[],
        classifications:classificationArray,
		tariffs:[],
		amenities:[],
		termsAndConditions:[]
	});
	product.save(function(err,a){
		if(err) return res.send(500,'Error Occured: database error');
		res.json({'status':'Product '+a._id+' Created '});
	});

});

// List Product Detail

ProductController.get('/product/:id',function(req,res){
	Product.findById(req.params.id,function(err,product){
		if(req.session.passport.user)
            res.render("product-view",{'product':product,layout:'list'});
            //res.status(200).json({product:product});
        else
            res.redirect('/account/session');
        //res.status(200).json({product:product});
        
	})
});

//Update product details
ProductController.get('/productDetails/:id',function(req,res){
	Product.findById(req.params.id,function(err,product){
		if(req.session.passport.user)
            res.render("update-product-details",{'product':product,layout:'list'});
        else
            res.redirect('/account/session');
        //res.status(200).json({product:product});
        
	})
});

//Create new Image
ProductController.get('/:productId/:source/add-new-image',function(req,res){
	Product.findById(req.params.id,function(err,product){
		//res.status(200).json({product:product});
        prodId = req.params.productId;
        destName = req.params.source;
        res.render("add-new-image",{'productId':prodId,'dest':destName,layout:'list'});
	})
});

//Create new Address
ProductController.get('/:productId/add-new-address',function(req,res){
	Product.findById(req.params.id,function(err,product){
		//res.status(200).json({product:product});
        prodId = req.params.productId;
        res.render("add-new-address",{'productId':prodId,layout:'list'});
	})
});

//Create new tariff
ProductController.get('/:productId/add-new-tariff',function(req,res){
	Product.findById(req.params.id,function(err,product){
		//res.status(200).json({product:product});
        prodId = req.params.productId;
        res.render("add-new-tariff",{'productId':prodId,layout:'list'});
	})
});

//Create new Amenity
ProductController.get('/:productId/add-new-amenity',function(req,res){
	Product.findById(req.params.id,function(err,product){
		//res.status(200).json({product:product});
        prodId = req.params.productId;
        res.render("add-new-amenity",{'productId':prodId,layout:'list'});
	})
});

//Create new termsAndConditions
ProductController.get('/:productId/add-new-termsAndConditions',function(req,res){
	Product.findById(req.params.id,function(err,product){
		//res.status(200).json({product:product});
        prodId = req.params.productId;
        res.render("add-new-termsAndConditions",{'productId':prodId,layout:'list'});
	})
});

//Create new phonenumber
ProductController.get('/:productId/add-new-phoneNumber',function(req,res){
	Product.findById(req.params.id,function(err,product){
		//res.status(200).json({product:product});
        prodId = req.params.productId;
        res.render("add-new-phoneNumber",{'productId':prodId,layout:'list'});
	})
});

//Get the address details
ProductController.get('/:productId/add-edit-address/:addressId',function(req,res){
    productId = req.param.productId;
	Product.findOne({_id:productId},'addresses',function(err,product){
		if(err) return res.send(500,'Error Occured During Adddress Retrieval for Product with Id['+productId+']');
		//res.status(200).json({'addresses':product.addresses});
        res.render("update-addresses",{'addresses':product.addresses,layout:'list'});

	});
});

//Update Product Detail

ProductController.post('/product/:id',function(req,res){

	productToBeUpdated = {		
		name:req.body.name,
		type:req.body.type,
		description:req.body.description,
		emailAddress:req.body.emailAddress,
		is_active:req.body.is_active
	};

	Product.findOneAndUpdate({_id:req.params.id},productToBeUpdated,{upsert:false},function(err,product){
		if(err) return res.send(500,'Error Occured: database error during Product Updation');
		res.json({'status':'Product '+product._id+' Updated '});

	});
});


// Delete Product By Id

ProductController.delete('/product/:id',function(req,res){
	Product.findById(req.params.id,function(err,product){
		if(err)return res.send(500,'Error Occured:database error'+err);
		product.remove();
		res.status(200).json({'status':'Product '+req.params.id +' Deleted'});
	});
});

//Get Address By Product ID & Address ID

ProductController.get('/:productId/addresses/:addressId',function(req,res){
	productId = req.params.productId;
	addressId = req.params.addressId;

	Product.find(
		{_id:productId},
		{addresses:{$elemMatch:
			{
				_id:addressId
			}
		}
		},
		function(err,product){
		res.render("update-address",{'productAddress':product[0].addresses[0],'productId':productId,layout:'list'});
	});

});
//Get image By Product ID & Address ID

ProductController.get('/:productId/image/:imageId/:source',function(req,res){
	productId = req.params.productId;
	imageId = req.params.imageId;
    dest = req.params.source;
    console.log(productId);
	Product.find(
		{_id:productId},
		{images:{$elemMatch:
			{
				_id:imageId
			}
		  }
		},
		function(err,product){
        //res.status(200).json({product:product});
		res.render("update-image",{'productImage':product[0].images[0],'productId':productId,'dest':dest,layout:'list'});
	});

});

//Get tariff By Product ID & Tariff ID

ProductController.get('/:productId/tariff/:tariffId',function(req,res){
	productId = req.params.productId;
	tariffId = req.params.tariffId;

	Product.find(
		{_id:productId},
		{tariffs:{$elemMatch:
			{
				_id:tariffId
			}
		}
		},
		function(err,product){
		res.render("update-tariff",{'productTariff':product[0].tariffs[0],'productId':productId,layout:'list'});
	});

});

//Get Amenities By Product ID & Amenities ID

ProductController.get('/:productId/amenity/:amenityId',function(req,res){
	productId = req.params.productId;
	amenityId = req.params.amenityId;

	Product.find(
		{_id:productId},
		{amenities:{$elemMatch:
			{
				_id:amenityId
			}
		}
		},
		function(err,product){
		res.render("update-amenity",{'productAmenities':product[0].amenities[0],'productId':productId,layout:'list'});
	});

});

//Get TermsAndConditions By Product ID & termandcondition ID

ProductController.get('/:productId/termsAndConditions/:amenityId',function(req,res){
	productId = req.params.productId;
	termsAndConditionsId = req.params.amenityId;

	Product.find(
		{_id:productId},
		{termsAndConditions:{$elemMatch:
			{
				_id:termsAndConditionsId
			}
		}
		},
		function(err,product){
		res.render("update-termsAndConditions",{'producttermsAndConditions':product[0].termsAndConditions[0],'productId':productId,layout:'list'});
	});

});

//Get Phone Number By Product ID & Phone ID

ProductController.get('/:productId/phone/:phoneId',function(req,res){
	productId = req.params.productId;
	phoneId = req.params.phoneId;

	Product.find(
		{_id:productId},
		{phoneNumbers:{$elemMatch:
			{
				_id:phoneId
			}
		}
		},
		function(err,product){
		res.render("update-phone",{'productPhone':product[0].phoneNumbers[0],'productId':productId,layout:'list'});
	});

});

// List All Addresses 

ProductController.get('/:id/addresses',function(req,res){
	productId = req.params.id;
	Product.findOne({_id:productId},'addresses',function(err,product){
		if(err) return res.send(500,'Error Occured During Adddress Retrieval for Product with Id['+productId+']');
		res.status(200).json({'addresses':product.addresses});
        //res.render("update-addresses",{'addresses':product.addresses,layout:'list'});

	});
});

// List All PhoneNumbers

ProductController.get('/:id/phoneNumbers',function(req,res){
	productId = req.params.id;
	Product.findOne({_id:productId},'phoneNumbers',function(err,product){
		if(err) return res.send(500,'Error Occured During PhoneNumbers Retrieval for Product with Id['+productId+']');
		res.status(200).json({'phoneNumbers':product.phoneNumbers});

	});
});

// List All Tariffs

ProductController.get('/:id/tariffs',function(req,res){
	productId = req.params.id;
	Product.findOne({_id:productId},'tariffs',function(err,product){
		if(err) return res.send(500,'Error Occured During Tariffs Retrieval for Product with Id['+productId+']');
		res.status(200).json({'tariffs':product.tariffs});

	});
});

// List All Amenities

ProductController.get('/:id/amenities',function(req,res){
	productId = req.params.id;
	Product.findOne({_id:productId},'amenities',function(err,product){
		if(err) return res.send(500,'Error Occured During Amenities Retrieval for Product with Id['+productId+']');
		res.status(200).json({'amenities':product.amenities});

	});
});

// List All TermsAndConditions

ProductController.get('/:id/termsAndConditions',function(req,res){
	productId = req.params.id;
	Product.findOne({_id:productId},'termsAndConditions',function(err,product){
		if(err) return res.send(500,'Error Occured During TermsAndConditions Retrieval for Product with Id['+productId+']');
		res.status(200).json({'termsAndConditions':product.termsAndConditions});

	});
});


// Add TermsAndConditions

ProductController.post('/:id/termsconditions',function(req,res){
	productId = req.params.id;
	newTermsCondition={
		description:req.body.description,
	};

	Product.update({_id:productId},{
		$push:
			{'termsAndConditions':
					newTermsCondition
			}
		},
		{upsert:true},function(err){
			if(err) return res.send(500,'Error Occured During Terms & Conditions Update for Product with Id['+productId+']');
			res.json({'status':'New Terms & Conditions Details Created for Product ['+productId+']'});
		});
});


// Add Amenities

ProductController.post('/:id/amenity',function(req,res){
	productId = req.params.id;
	newAmenity={
		description:req.body.description,
	};

	Product.update({_id:productId},{
		$push:
			{'amenities':
					newAmenity
			}
		},
		{upsert:true},function(err){
			if(err) return res.send(500,'Error Occured During Amenity Update for Product with Id['+productId+']');
			res.json({'status':'New Amenity Details Created for Product ['+productId+']'});
		});
});




// Add Tarriffs

ProductController.post('/:id/tariff',function(req,res){
	productId = req.params.id;
	newTariff={
		description:req.body.description,
		cost:req.body.cost,
        tax:req.body.tax
	};

	Product.update({_id:productId},{
		$push:
			{'tariffs':
					newTariff
			}
		},
		{upsert:true},function(err){
			if(err) return res.send(500,'Error Occured During Tariff Update for Product with Id['+productId+']');
			res.json({'status':'New Tariff Details Created for Product ['+productId+']'});
		});
});



// Add PhoneNumbers

ProductController.post('/:id/phone',function(req,res){
	productId = req.params.id;
	newPhoneNumber={
		contactType:req.body.contactType,
		contactNumber:req.body.contactNumber
	};

	Product.update({_id:productId},{
		$push:
			{'phoneNumbers':
					newPhoneNumber
			}
		},
		{upsert:false},function(err){
			if(err) return res.send(500,'Error Occured During Phone Update for Product with Id['+productId+']');
			res.json({'status':'New Phone Details Created for Product ['+productId+']'});
		});
});

// Add Address

ProductController.post('/:id/address',function(req,res){
	productId = req.params.id;
	newAddress = {
		address1 :req.body.address1,
		address2 : req.body.address2,
		city : req.body.city,
		state :req.body.state,
		postalCode : req.body.postalCode
	};

	Product.update({_id:productId},
		{
			$push:{'addresses':
					newAddress
				}}
				,{upsert:true}
		,function(err){
		if(err) return res.send(500,'Error Occured During Address Update for Product with Id['+productId+']');
		res.json({'status':'Address Created for Product ['+productId+']'});
	});
});

// Add Image

ProductController.post('/:id/:source/image',multer({
    dest:"./uploads/",
    rename: function (fieldname, filename) {
        return filename+Date.now();
    },
    changeDest:function(dest,req,res){
        var newDestination = dest + req.params.source;
        var stat = null;
        try {
            stat = fs.statSync(newDestination);
        } catch (err) {
            fs.mkdirSync(newDestination);
        }
        if (stat && !stat.isDirectory()) {
            throw new Error('Directory cannot be created because an inode of a different type exists at "' + dest + '"');
        }
        return newDestination   
    },
    onFileUploadComplete: function (file) {
      console.log(file.fieldname + ' uploaded to  ' + file.name);
        imageName = file.name;
      done=true;
    }
}),function(req,res){
	productId = req.params.id;
    captionText = req.body.caption;
    console.log(imageName);
	newImage = {
		imageUrl :imageName,
		captionText:captionText
	};
	Product.update({_id:productId},
		{
			$push:{'images':
					newImage
				}}
				,{upsert:true}
		,function(err){
		if(err) return res.send(500,'Error Occured During Address Update for Product with Id['+productId+']');
		//res.json({'status':'Address Created for Product ['+productId+']'});
        var filename = req.files.imageUrl.name;
        var path = req.files.imageUrl.path;
        var type = req.files.imageUrl.mimetype;
        var read_stream =  fs.createReadStream(dirname + '/' + path);                    
        var writestream = gfs.createWriteStream({
            filename: req.files.imageUrl.name
        });
        read_stream.pipe(writestream);
        res.redirect("/products/product/"+productId);
	});
});
// Update Address

ProductController.post('/:productId/address/:addressId',function(req,res){
	
	productId = req.params.productId;
	addressId = req.params.addressId;

	addressToBeUpdated = {
		address1 :req.body.address1,
		address2 : req.body.address2,
		city : req.body.city,
		state :req.body.state,
		postalCode : req.body.postalCode,
		_id:addressId
	};

	Product.update({_id:productId,'addresses._id':addressId},
		{
			$set:{'addresses.$':addressToBeUpdated}}
		,function(err){
		if(err) return res.send(500,'Error Occured During Address Update for Product with Id['+productId+']'+err);
		res.json({'status':'Address Updated for Product ['+productId+']'});
	});
});

// Update images

ProductController.post('/:productId/image/:imageId/:source',multer({
   dest:"./uploads/",
    rename: function (fieldname, filename) {
        return filename+Date.now();
    },
    changeDest:function(dest,req,res){
        var newDestination = dest + req.params.source;
        var stat = null;
        try {
            stat = fs.statSync(newDestination);
        } catch (err) {
            fs.mkdirSync(newDestination);
        }
        if (stat && !stat.isDirectory()) {
            throw new Error('Directory cannot be created because an inode of a different type exists at "' + dest + '"');
        }
        return newDestination   
    },
    onFileUploadComplete: function (file) {
      console.log(file.fieldname + ' uploaded to  ' + file.name);
        imageName = file.name;
      done=true;
    } 
}),function(req,res){
	
	productId = req.params.productId;
	imageId = req.params.imageId;
    dest = req.params.source;
    prevUrl = req.body.prevUrl;
    
    bUrl = "/products/product/"+productId;
    var fileImage = imageName;
    
    if(imageName =="" || imageName === undefined){
        imageName = req.body.imgUrl;   
    }
	imageToBeUpdated = {
		imageUrl:imageName,
        captionText:req.body.caption,
		_id:imageId
	};
    if(fileImage.trim() != "" && req.body.prevUrl != "" && fileImage.trim() != req.body.prevUrl ){
        try{
        fs.unlink('uploads/'+dest+"/"+prevUrl, function (err) {
          if (err) throw err;
          console.log('successfully deleted '+prevUrl);
        });
        
        gfs.remove({filename:prevUrl}, function (err) {
          if (err) return handleError(err);
          console.log('success');
        });
        }
        catch(e){
            console.log("something went wrong");   
        }
    }

	Product.update({_id:productId,'images._id':imageId},
		{
			$set:{'images.$':imageToBeUpdated}}
		,function(err){
		if(err) return res.send(500,'Error Occured During Address Update for Product with Id['+productId+']'+err);
		
        
        backUrl = '/categories/category/'+req.params.id;
        if(req.files.imageUrl !== undefined){
            var filename = req.files.imageUrl.name;
            var path = req.files.imageUrl.path;
            var type = req.files.imageUrl.mimetype;
            var read_stream =  fs.createReadStream(dirname + '/' + path);                    
            var writestream = gfs.createWriteStream({
                filename: req.files.imageUrl.name
            });
            read_stream.pipe(writestream);
            console.log('gridfs uploaded'+req.files.imageUrl.name);
        }
        //res.json({'status':'Address Updated for Product ['+productId+']'});
        res.redirect(bUrl);
	});
});


// Delete image

ProductController.delete('/:productId/:dest/image/:imageId/:imageName',function(req,res){
	productId = req.params.productId;
	imageId = req.params.imageId;
    dest = req.params.dest;
    imgaeName = req.params.imageName;

	Product.update({_id:productId},
	{
		$pull:{images:{_id:imageId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During Address Delete for Product with Id['+productId+']');
				res.json({'status':'Address Deleted for Product ['+productId+']'});
                fs.unlink('uploads/'+dest+"/"+imgaeName, function (err) {
                  if (err) throw err;
                  console.log('successfully deleted '+req.body.prevImgUrl);
                });
                gfs.remove({filename:imgaeName}, function (err) {
                  if (err) return handleError(err);
                  console.log('success');
                });
                
	});
});

// Delete Address

ProductController.delete('/:productId/address/:addressId',function(req,res){
	productId = req.params.productId;
	addressId = req.params.addressId;

	Product.update({_id:productId},
	{
		$pull:{addresses:{_id:addressId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During Address Delete for Product with Id['+productId+']');
				res.json({'status':'Address Deleted for Product ['+productId+']'});
	});
});


// Update TermsAndCondition

ProductController.post('/:productId/termsAndCondition/:termsAndConditionId',function(req,res){
	
	productId = req.params.productId;
	termsAndConditionId = req.params.termsAndConditionId;

	termsAndConditionToBeUpdated = {
		description:req.body.description,
		_id:termsAndConditionId
	};


	Product.update({_id:productId,'termsAndConditions._id':termsAndConditionId},
		{
			$set:{'termsAndConditions.$':termsAndConditionToBeUpdated}}
		,function(err){
		if(err) return res.send(500,'Error Occured During TermsAndCondition Update for Product with Id['+productId+']'+err);
		res.json({'status':'TermsAndCondition Updated for Product ['+productId+']'});
	});
});

// Delete TermsAndCondition

ProductController.delete('/:productId/termsAndCondition/:termsConditionId',function(req,res){
	productId = req.params.productId;
	termsConditionId = req.params.termsConditionId;

	Product.update({_id:productId},
	{
		$pull:{termsAndConditions:{_id:termsConditionId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During TermsCondition Delete for Product with Id['+productId+']');
				res.json({'status':'TermsCondition Deleted for Product ['+productId+']'});
	});
});

// Update Amenity

ProductController.post('/:productId/amenity/:amenityId',function(req,res){
	
	productId = req.params.productId;
	amenityId = req.params.amenityId;

	amenityToBeUpdated = {
		description:req.body.description,
		_id:amenityId
	};

	Product.update({_id:productId,'amenities._id':amenityId},
		{
			$set:{'amenities.$':amenityToBeUpdated}}
		,function(err){
		if(err) return res.send(500,'Error Occured During Amenity Update for Product with Id['+productId+']'+err);
		res.json({'status':'Amenity Updated for Product ['+productId+']'});
	});
});


//Delete Amenity

ProductController.delete('/:productId/amenity/:amenityId',function(req,res){
	productId = req.params.productId;
	amenityId = req.params.amenityId;

	console.log("Amenity Delete Invoked ...");

	Product.update({_id:productId},
	{
		$pull:{amenities:{_id:amenityId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During Amenity Delete for Product with Id['+productId+']');
				res.json({'status':'Amenity Deleted for Product ['+productId+']'});
	});
});

// Update Tariff

ProductController.post('/:productId/tariff/:tariffId',function(req,res){
	
	productId = req.params.productId;
	tariffId = req.params.tariffId;

	tariffToBeUpdated = {
		description:req.body.description,
		cost:req.body.cost,
        tax:req.body.tax,
		_id:tariffId
	};

	Product.update({_id:productId,'tariffs._id':tariffId},
		{
			$set:{'tariffs.$':tariffToBeUpdated}}
		,function(err){
		if(err) return res.send(500,'Error Occured During Tariff Update for Product with Id['+productId+']'+err);
		res.json({'status':'Tariff Updated for Product ['+productId+']'});
	});
});

//Delete Tariff

ProductController.delete('/:productId/tariff/:tariffId',function(req,res){
	productId = req.params.productId;
	tariffId = req.params.tariffId;

	console.log("Tariff Delete Invoked ...");

	Product.update({_id:productId},
	{
		$pull:{tariffs:{_id:tariffId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During Tariff Delete for Product with Id['+productId+']');
				res.json({'status':'Tariff Deleted for Product ['+productId+']'});
	});
});


// Update PhoneNumber

ProductController.post('/:productId/phoneNumber/:phoneNumberId',function(req,res){
	
	productId = req.params.productId;
	phoneNumberId = req.params.phoneNumberId;

	phoneNumberToBeUpdated = {
		contactType:req.body.contactType,
		contactNumber:req.body.contactNumber,
		_id:phoneNumberId
	};

	Product.update({_id:productId,'phoneNumbers._id':phoneNumberId},	
		{
			$set:{'phoneNumbers.$':phoneNumberToBeUpdated}}
		,function(err){
		if(err) return res.send(500,'Error Occured During PhoneNumber Update for Product with Id['+productId+']'+err);
		res.json({'status':'PhoneNumber Updated for Product ['+productId+']'});
	});
});

//Delete PhoneNumber

ProductController.delete('/:productId/phoneNumber/:phoneNumberId',function(req,res){
	productId = req.params.productId;
	phoneNumberId = req.params.phoneNumberId;

	console.log("PhoneNumber Delete Invoked ...");

	Product.update({_id:productId},
	{
		$pull:{phoneNumbers:{_id:phoneNumberId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During PhoneNumber Delete for Product with Id['+productId+']');
				res.json({'status':'PhoneNumber Deleted for Product ['+productId+']'});
	});
});
//Add new classification for product
ProductController.get('/:productId/classification',function(req,res){
    var productId = req.params.productId;
	ClassificationGroup.find({'is_active':true},function(err,classifications){
		res.render("add-product-classification",{'classifications':classifications,'productId':productId,layout:'list'});
    }); 
});

//add new classification
ProductController.post('/:id/classification',function(req,res){
    var productId = req.params.id;
    var classificationName = req.body.classification;
    newClassification={
		name:classificationName
	};
    Product.findOne({_id:productId},{classifications:{$elemMatch:{name:classificationName}}},function(err,prodClass){
        if(err) {
            return res.send(500,'Error Occured During Phone Update for Product with Id['+productId+']');
        }
        else{
            if(prodClass.classifications != ""){
                //res.json({"msg":prodClass.classification});
                ClassificationGroup.find({'is_active':true},function(err,classifications){
                    res.json({"msg":"Already classification added for this product"});
                    //res.render("add-category-classification",{msg:"Aleready classification added for this category",'classifications':classifications,'productId':productId,layout:'list'});
                }); 
                
            }
            else{
            Product.update({_id:productId},{
            $push:
                {'classifications':
                        newClassification
                }
            },
            {upsert:false},function(err){
                if(err) return res.send(500,'Error Occured During Phone Update for Product with Id['+productId+']');
                //res.json({'status':'New Phone Details Created for Product ['+categoryId+']'});
                res.redirect("/products/product/"+productId);
            });
            }
        }
    });
	
});

// Delete classification

ProductController.delete('/:productId/productclassification/:classId',function(req,res){
	productId = req.params.productId;
	classId = req.params.classId;

	Product.update({_id:productId},
	{
		$pull:{classifications:{_id:classId}}
	},{multi:true}
		,function(err){
				if(err) return res.send(500,'Error Occured During TermsCondition Delete for Product with Id['+productId+']');
				res.json({'status':'TermsCondition Deleted for Product ['+productId+']'});
	});
});

// Add tax details
ProductController.post('/:id/:tariffId/taxdetails',function(req,res){
	productId = req.params.id;
	tariffId = req.params.tariffId;
	newTaxDetails={
		taxType:req.body.taxType,
		percentage:req.body.percentage,
		amount:req.body.amount
	};

	Product.update({_id:productId,tarriff:{_id:tariffId}},{
		$push:
			{'tariff':
                {'tax': 
                    newTaxDetails
                }
			}
		},
		{upsert:false},function(err){
			if(err) return res.send(500,'Error Occured During Phone Update for Product with Id['+productId+']');
			res.json({'status':'New Phone Details Created for Product ['+productId+']'});
		});
});

//TODO : search specific params ..


module.exports = ProductController;
